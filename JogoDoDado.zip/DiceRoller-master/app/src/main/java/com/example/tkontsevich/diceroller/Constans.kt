package com.example.tkontsevich.diceroller

const val LOG_TAG = "roll_dice"